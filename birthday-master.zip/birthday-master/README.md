Happy Birthday

A Happy Birthday animation design in CSS3, HTML5.

URL: http://ayusharma.github.io/birthday/

Technology Used: HTML5 CSS3 jQuery  GNU/Linux Digital Ocean as VPS GIMP

# Setup

## If you have python installed:
```
cd Birthday
```

&& 

```
python -m SimpleHTTPServer --port  8081
```

visit http://localhost:8081 in your browser.

## If you have nodejs installed
```
npm install
```
&&

```
npm run server-node
```
visit http://localhost:8081 in your browser.


## For further queries do not hesitate to contact me.

Ayush Sharma Arya College Of Engineering & IT, Jaipur India.

contact details: ayush.aceit@gmail.com

IRC: ayushpix
